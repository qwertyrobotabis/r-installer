function scrollToProjects() {
    document.getElementById("projects").scrollIntoView({ behavior: "smooth" });
}

document.addEventListener("DOMContentLoaded", () => {
    const statDetails = [
        {
            target: 1885,
            label: "Total Requests",
            containerId: "requests-counter"
        },
        {
            target: 2,
            label: "API Features",
            containerId: "features-counter"
        },
        {
            target: 2597,
            label: "Happy Developers",
            containerId: "developers-counter"
        }
    ];

    statDetails.forEach(stat => {
        const targetNumber = stat.target;
        const numberString = String(targetNumber).padStart(
            String(targetNumber).length,
            "0"
        );
        const container = document.getElementById(stat.containerId);

        // Create digit boxes
        for (let i = 0; i < numberString.length; i++) {
            const statsBox = document.createElement("div");
            statsBox.classList.add("stats-box");
            statsBox.dataset.digit = "0"; // Initialize with "0"

            // Create four faces
            for (let j = 0; j < 4; j++) {
                const statsFace = document.createElement("div");
                statsFace.classList.add("stats-face");
                statsFace.style.setProperty("--i", j);

                // Initially all faces show "0" or the next digit
                if (j === 0) {
                    statsFace.textContent = "0";
                } else if (j === 1) {
                    statsFace.textContent = "1"; // Next face
                }
                statsBox.appendChild(statsFace);
            }
            container.appendChild(statsBox);
        }

        // Add label
        const labelEl = document.createElement("span");
        labelEl.classList.add("stat-label");
        labelEl.textContent = stat.label;
        container.appendChild(labelEl);
    });

    function animateStatsBoxes(statContainer, target) {
        const boxes = statContainer.querySelectorAll(".stats-box");
        const targetString = String(target).padStart(boxes.length, "0");

        boxes.forEach((box, index) => {
            let currentDigit = parseInt(box.dataset.digit, 10) || 0;
            const targetDigit = parseInt(targetString[index], 10);

            if (currentDigit === targetDigit) return; // Skip if already correct

            function animateDigit(current, target, rotation = 0) {
                if (current === target) return;

                let nextDigit = (current + 1) % 10;
                rotation += 360; // Full rotation

                // **Update number BEFORE the animation completes**
                box.querySelectorAll(".stats-face").forEach((face, i) => {
                    face.textContent = (nextDigit + i) % 10;
                });

                // Apply rotation
                box.style.transition = "transform 0.6s ease-in-out";
                box.style.transform = `rotateX(${rotation}deg)`;

                // Delay next update slightly to keep pace with animation
                setTimeout(() => {
                    box.dataset.digit = nextDigit;
                    animateDigit(nextDigit, target, rotation);
                }, 600);
            }

            animateDigit(currentDigit, targetDigit);
        });
    }

    const statsSection = document.querySelector(".stats-section");
    const observer = new IntersectionObserver(
        entries => {
            if (entries[0].isIntersecting) {
                statDetails.forEach(stat => {
                    const container = document.getElementById(stat.containerId);
                    animateStatsBoxes(container, stat.target);
                });
            }
        },
        { threshold: 0.5 }
    );
    observer.observe(statsSection);
});
